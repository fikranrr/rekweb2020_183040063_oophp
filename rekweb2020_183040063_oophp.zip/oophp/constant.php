<?php

// define ('NAMA', 'Fikran Rakadifa');
// echo NAMA;

// echo "<br>";

// const UMUR = 20;
// echo UMUR;



// class Coba {
// 	const NAMA = 'Fikran';
// }

// echo Coba::NAMA;


// echo __LINE__;
// echo __DIR__;
// echo __TRAIT__;
// echo __METHOD__;
// echo __NAMESPACE__;


// function coba() {
// 	return __FUNCTION__;
// }

// echo coba();



class Coba {
	public $kelas = __CLASS__;
}

$obj = new Coba;
echo $obj->kelas;





















?>